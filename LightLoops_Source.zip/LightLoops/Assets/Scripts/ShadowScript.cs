using UnityEngine;
using System.Collections;

public class ShadowScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		renderer.material.color = Color.black;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
